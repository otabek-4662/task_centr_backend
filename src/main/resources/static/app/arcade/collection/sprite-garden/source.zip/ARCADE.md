# Sprite Garden in Choyxona Arcade

Based on Karl Herrick’s Sprite Garden, revision `76741a5269ecd62158a315762719cca16fd7a123`, under GNU AGPL v3.

Build the browser modules with:

```
npm ci --prefix arcade-build
node arcade-build.cjs
```

Serve `dist/assets/` as `assets/` beside `index.html`. Deploy `arcade-index.html`, `arcade-about.html`, `arcade-privacy.html`, and `arcade-examples.html` without the `arcade-` prefix. The game frame loads Choyxona’s `score-bridge.js` from `../../score-bridge.js` to store game saves through the enclosing page. A copy of that client bridge accompanies this source. The game can also run independently with in-memory saves.

This build uses local dependencies, an isolated browser save adapter, and Uzbek text for primary controls. Third-party license notices are in `third-party/`. The full dependency versions are in `arcade-build/package-lock.json`.
