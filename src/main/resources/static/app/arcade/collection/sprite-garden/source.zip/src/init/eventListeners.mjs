import extrasHandler from "konami-code-js";

import { createSaveState } from "../state/createSave.mjs";
import { loadSaveState } from "../state/loadSave.mjs";
import {
  tutorialListener,
  gameConfig,
  gameState,
  hasDismissedTutorial,
  hasEnabledExtras,
} from "../state/state.mjs";

import { initTrain } from "../api/train/index.mjs";

import { copyToClipboard } from "../util/copyToClipboard.mjs";
import { debounce } from "../util/debounce.mjs";
import { dismissTutorialToast } from "../util/dismissTutorialToast.mjs";
import { extractAttachments } from "../util/extractAttachments.mjs";
import { extractJsonFromPng } from "../util/canvasToPngWithState.mjs";
import { getCustomProperties } from "../util/colors/getCustomProperties.mjs";

import { getRandomSeed } from "../misc/getRandomSeed.mjs";
import { handleBreakBlockWithWaterPhysics } from "../misc/handleBreakBlock.mjs";
import { handleFarmAction } from "../misc/handleFarmAction.mjs";
import { handlePlaceBlock } from "../misc/handlePlaceBlock.mjs";
import { resizeCanvas } from "../util/resizeCanvas.mjs";
import { runCompress } from "../util/compression.mjs";
import { selectMaterial } from "../misc/selectMaterial.mjs";
import { selectSeed } from "../misc/selectSeed.mjs";
import { showColorCustomizationDialog } from "../misc/customColors.mjs";
import { toggleBreakMode } from "../misc/toggleBreakMode.mjs";

import { updateRangeUI } from "../update/ui/range.mjs";
import {
  updateMovementScaleUI,
  updateMovementScaleValue,
} from "../update/ui/movementScale.mjs";

import { showExamplesDialog } from "../dialog/examples.mjs";
import { showPrivacyDialog } from "../dialog/privacy.mjs";
import { showToast } from "../dialog/showToast.mjs";
import { showAboutDialog } from "../dialog/about.mjs";
import {
  autoSaveGame,
  getSaveMode,
  setSaveMode,
  showStorageDialog,
} from "../dialog/storage.mjs";

import { initFog } from "./fog.mjs";
import { initNewWorld } from "./newWorld.mjs";

/** @typedef {import('./game.mjs').CustomShadowHost} CustomShadowHost */

/**
 * @param {typeof globalThis} gThis - The global `this` context (global object), typically `window` in browsers.
 * @param {ShadowRoot} shadow - The shadow DOM root element where the game components are rendered.
 *
 * @returns {void}
 */
export function initGlobalEventListeners(gThis, shadow) {
  const debouncedResize = debounce(() => {
    resizeCanvas(shadow, gameConfig);
  }, 200);

  const resizeObserver = new ResizeObserver((entries) => {
    debouncedResize();
  });

  resizeObserver.observe(shadow.host);

  setupDialogButtons(gThis, shadow);
  setupMovementScaleUI(shadow);

  updateRangeUI(shadow);
  updateMovementScaleUI(shadow);

  const closeWorldGenerationBtn = shadow.getElementById("closeWorldGeneration");
  if (closeWorldGenerationBtn) {
    closeWorldGenerationBtn.addEventListener("click", () => {
      shadow
        .querySelector('[class="seed-controls"]')
        .setAttribute("hidden", "hidden");
    });
  }
  const customizeColors = shadow.getElementById("customizeColorsBtn");
  if (customizeColors) {
    const config = gThis.spriteGarden.config;
    customizeColors.addEventListener("click", async () => {
      const initialResolution = config.currentResolution.get();

      if (initialResolution === "400") {
        config.currentResolution.set("800");
        resizeCanvas(shadow, config);

        const colorDialog = await showColorCustomizationDialog(gThis);
        colorDialog.dialog.addEventListener("close", () => {
          config.currentResolution.set(initialResolution);

          resizeCanvas(shadow, config);
        });

        return;
      }

      await showColorCustomizationDialog(gThis);
    });
  }
}

/**
 * @param {ShadowRoot} shadow
 *
 * @returns {void}
 */
function setupMovementScaleUI(shadow) {
  const scaleKey = shadow.querySelector('[data-key="x"].middle');

  if (scaleKey) {
    scaleKey.addEventListener(
      "click",
      async () => await updateMovementScaleValue(shadow),
    );

    scaleKey.addEventListener(
      "touchstart",
      async () => await updateMovementScaleValue(shadow),
    );
  }
}

/**
 * @param {typeof globalThis} gThis
 * @param {ShadowRoot} shadow
 *
 * @returns {void}
 */
function setupDialogButtons(gThis, shadow) {
  const aboutBtn = shadow.getElementById("aboutBtn");

  if (aboutBtn) {
    aboutBtn.addEventListener("click", async function () {
      try {
        await showAboutDialog(gThis.document, shadow);
      } catch (error) {
        console.error("Failed to open about dialog:", error);

        alert("Failed to open about dialog. Check console for details.");
      }
    });
  }

  // Examples button
  const examplesBtn = shadow.getElementById("examplesBtn");
  if (examplesBtn) {
    examplesBtn.addEventListener("click", async function () {
      try {
        await showExamplesDialog(gThis.document, shadow);
      } catch (error) {
        console.error("Failed to open examples dialog:", error);

        alert("Failed to open examples dialog. Check console for details.");
      }
    });
  }

  // Privacy button
  const privacyBtn = shadow.getElementById("privacyBtn");
  if (privacyBtn) {
    privacyBtn.addEventListener("click", async function () {
      try {
        await showPrivacyDialog(gThis.document, shadow);
      } catch (error) {
        console.error("Failed to open privacy dialog:", error);

        alert("Failed to open privacy dialog. Check console for details.");
      }
    });
  }
}

/**
 * @param {MouseEvent} e
 *
 * @returns {void}
 */
function handleCornerClick(e) {
  e.preventDefault();
  e.stopPropagation();

  const heading = e.currentTarget;
  if (heading instanceof HTMLDivElement) {
    const cornerContainer = heading.nextElementSibling;
    const show = cornerContainer.hasAttribute("hidden");
    cornerContainer.toggleAttribute("hidden", !show);

    if (heading.parentElement.id === "controls") {
      heading.getRootNode().querySelector(".touch-controls").toggleAttribute("hidden", !show);
    }
  }
}

/**
 * @param {typeof globalThis} gThis
 * @param {ShadowRoot} shadow
 *
 * @returns {void}
 */
export function initDocumentEventListeners(gThis, shadow) {
  // Extras
  new extrasHandler((handler) => {
    shadow.getElementById("mapEditor").removeAttribute("hidden");
    shadow
      .getElementById("customizeColorsBtnContainer")
      .removeAttribute("hidden");
    shadow.getElementById("examplesBtnContainer").removeAttribute("hidden");
    shadow
      .querySelector('sprite-garden-option[value="fullscreen"]')
      .removeAttribute("hidden");

    const customizeColorsDialog = shadow.getElementById(
      "customizeColorsDialog",
    );
    if (customizeColorsDialog) {
      customizeColorsDialog
        .querySelectorAll("[hidden]")
        .forEach((node) => node.removeAttribute("hidden"));
    }

    const settingsContainer = shadow.querySelector(
      '#settings > [class="ui-grid__corner--container"]',
    );

    settingsContainer.removeAttribute("hidden");

    const trainContainer = shadow.querySelector("#trainPanel");
    trainContainer.removeAttribute("hidden");
    initTrain();

    hasEnabledExtras.set(true);
    handler.disable();
  });

  // Toast Event Listener
  shadow.addEventListener("sprite-garden-toast", (e) => {
    if (e instanceof CustomEvent) {
      showToast(shadow, e.detail.message, e.detail.config);
    }
  });

  tutorialListener.set((e) => {
    if (e instanceof KeyboardEvent && !hasDismissedTutorial.get()) {
      const key = e.key.toLowerCase();

      if (key === "w" || key === "arrowup" || key === " ") {
        dismissTutorialToast(shadow);

        hasDismissedTutorial.set(true);
      }
    }
  });

  shadow.addEventListener("keydown", tutorialListener.get());

  // Keyboard events
  shadow.addEventListener(
    "keydown",
    /** @param {KeyboardEvent} e */
    async (e) => {
      const lowercaseKey = e.key.toLowerCase();

      const host =
        /** @type {CustomShadowHost} */
        (shadow.host);
      host.keys[lowercaseKey] = true;

      // Allow digits 0-9, enter, and delete
      if (lowercaseKey === "enter") {
        if (
          e.target instanceof HTMLInputElement &&
          e.target.getAttribute("id") === "worldSeedInput"
        ) {
          handleGenerateButton();
        }
      }

      // Always hide the world generation panel with escape
      if (lowercaseKey === "escape") {
        shadow
          .querySelector('[class="seed-controls"]')
          .setAttribute("hidden", "hidden");
      }

      // Add 'S' key to show / hide the world generation panel
      if (lowercaseKey === "s" && e.ctrlKey) {
        e.preventDefault();

        shadow
          .querySelector('[class="seed-controls"]')
          .toggleAttribute("hidden");
      }

      if (
        (lowercaseKey >= "0" && lowercaseKey <= "9") ||
        lowercaseKey === "backspace" ||
        lowercaseKey === "delete" ||
        lowercaseKey === "escape"
      ) {
        return;
      }

      // Add 'R' key to regenerate world with random seed
      if (lowercaseKey === "r" && e.ctrlKey) {
        e.preventDefault();

        handleRandomSeedButton();
      }

      // Add 'G' key to regenerate world with current seed (to see changes)
      if (lowercaseKey === "g" && e.ctrlKey) {
        e.preventDefault();

        handleGenerateButton();
      }

      // Add 'E' key to handle toggling the break mode
      if (lowercaseKey === "e") {
        e.preventDefault();

        toggleBreakMode();
      }

      // Add 'X' key to handle movement scale actions
      if (lowercaseKey === "x") {
        e.preventDefault();

        await updateMovementScaleValue(shadow);
      }

      // Handle farming actions
      if (lowercaseKey === "f") {
        handleFarmAction(
          shadow,
          gameState.growthTimers,
          gameState.plantStructures,
          gameState.player.get(),
          gameState.seedInventory.get(),
          gameState.selectedSeedType.get(),
          gameConfig.TILES,
          gameConfig.TILE_SIZE.get(),
          gameState.world.get(),
          gameConfig.WORLD_HEIGHT.get(),
          gameConfig.WORLD_WIDTH.get(),
        );
      }

      if (lowercaseKey === "r") {
        handleBreakBlockWithWaterPhysics(
          shadow,
          gameState.growthTimers,
          gameState.plantStructures,
          gameState.player,
          gameConfig.TILES,
          gameConfig.TILE_SIZE.get(),
          gameState.world,
          gameConfig.WORLD_HEIGHT.get(),
          gameConfig.WORLD_WIDTH.get(),
          gameState.waterPhysicsQueue,
          gameConfig.breakMode.get(),
        );
      }

      // Handle block placement keys
      const blockKeys = ["u", "i", "o", "j", "k", "l", "m", ",", "."];

      if (blockKeys.includes(lowercaseKey)) {
        await handlePlaceBlock(
          shadow,
          lowercaseKey,
          gameState.materialsInventory.get(),
          gameState.player.get(),
          gameState.selectedMaterialType.get(),
          gameConfig.TILES,
          gameConfig.TILE_SIZE.get(),
          gameState.world.get(),
          gameConfig.WORLD_HEIGHT.get(),
          gameConfig.WORLD_WIDTH.get(),
        );
      }

      e.preventDefault();
    },
  );

  const fogButton = shadow.getElementById("toggleFog");

  fogButton.addEventListener("click", function toggleFog() {
    const fogModeText = shadow.getElementById("fogModeText");

    if (fogModeText.textContent === "Clear") {
      gameConfig.fogMode.set("fog");

      return;
    }

    gameConfig.fogMode.set("clear");
  });

  function handleWorldStateButton() {
    shadow.querySelector('[class="seed-controls"]').toggleAttribute("hidden");
  }

  const worldStateBtn = shadow.getElementById("worldState");
  worldStateBtn.addEventListener("click", handleWorldStateButton);

  function handleGenerateButton() {
    /** @type string | null */
    let seedInputValue = null;
    const seedInput = shadow.getElementById("worldSeedInput");
    if (seedInput instanceof HTMLInputElement) {
      seedInputValue = seedInput.value;
    }

    const currentSeedDisplay = shadow.getElementById("currentSeed");

    const worldHeight = gameConfig.WORLD_HEIGHT.get();
    const worldWidth = gameConfig.WORLD_WIDTH.get();

    const currentWorld = initNewWorld(
      gameConfig.BIOMES,
      gameConfig.SURFACE_LEVEL.get(),
      gameConfig.TILE_SIZE.get(),
      gameConfig.TILES,
      worldHeight,
      worldWidth,
      gameConfig.worldSeed,
      gameState.gameTime,
      gameState.growthTimers,
      gameState.plantStructures,
      gameState.player,
      gameState.materialsInventory,
      gameState.seedInventory,
      Number(seedInputValue),
    );

    gameState.world.set(currentWorld);

    const colors = getCustomProperties(gThis, shadow);
    const currentFog = initFog(
      gameConfig.isFogScaled,
      worldHeight,
      worldWidth,
      colors,
    );

    // Set the fog in state
    gameState.exploredMap.set(currentFog);

    console.log(`Generated new world with seed: ${seedInputValue}`);

    currentSeedDisplay.textContent = seedInputValue;
  }

  function handleRandomSeedButton() {
    const currentSeedDisplay = shadow.getElementById("currentSeed");
    const seedInput = shadow.getElementById("worldSeedInput");

    const randomSeed = getRandomSeed();

    const worldHeight = gameConfig.WORLD_HEIGHT.get();
    const worldWidth = gameConfig.WORLD_WIDTH.get();

    const currentWorld = initNewWorld(
      gameConfig.BIOMES,
      gameConfig.SURFACE_LEVEL.get(),
      gameConfig.TILE_SIZE.get(),
      gameConfig.TILES,
      worldHeight,
      worldWidth,
      gameConfig.worldSeed,
      gameState.gameTime,
      gameState.growthTimers,
      gameState.plantStructures,
      gameState.player,
      gameState.materialsInventory,
      gameState.seedInventory,
      randomSeed,
    );

    gameState.world.set(currentWorld);

    const colors = getCustomProperties(gThis, shadow);
    const currentFog = initFog(
      gameConfig.isFogScaled,
      worldHeight,
      worldWidth,
      colors,
    );

    // Set the fog in state
    gameState.exploredMap.set(currentFog);

    console.log(`Generated new world with random seed: ${randomSeed}`);

    if (seedInput instanceof HTMLInputElement) {
      seedInput.value = String(randomSeed);
    }

    currentSeedDisplay.textContent = String(randomSeed);
  }

  const generateBtn = shadow.getElementById("generateWithSeed");
  generateBtn.addEventListener("click", handleGenerateButton);

  const randomBtn = shadow.getElementById("randomSeed");
  randomBtn.addEventListener("click", handleRandomSeedButton);

  const copySeedBtn = shadow.getElementById("copySeed");
  copySeedBtn.addEventListener("click", async function () {
    const seedInput = shadow.getElementById("worldSeedInput");

    if (seedInput instanceof HTMLInputElement) {
      await copyToClipboard(gThis, seedInput.value);
    }
  });

  const saveMode = shadow.getElementById("saveModeToggle");
  getSaveMode().then(async (mode) => {
    const resolvedMode = mode === "auto" ? "auto" : "manual";

    console.log("Save Mode:", resolvedMode);

    if (resolvedMode === "auto") {
      saveMode.innerText = "Avtomatik saqlash";
      saveMode.style.backgroundColor = "var(--sg-color-green-500)";

      return;
    }

    saveMode.innerText = "Qo‘lda saqlash";
    saveMode.style.backgroundColor = "var(--sg-color-red-500)";
  });

  saveMode.addEventListener("click", async function () {
    const mode = await getSaveMode();
    const resolvedMode = mode === "auto" ? "auto" : "manual";

    if (resolvedMode === "manual") {
      saveMode.innerText = "Avtomatik saqlash";
      saveMode.style.backgroundColor = "var(--sg-color-green-500)";

      await setSaveMode("auto");
      await autoSaveGame(gThis);

      return;
    }

    if (resolvedMode === "auto") {
      saveMode.innerText = "Qo‘lda saqlash";
      saveMode.style.backgroundColor = "var(--sg-color-red-500)";

      await setSaveMode("manual");
    }
  });

  const saveCompressedBtn = shadow.getElementById("saveExternalGameFile");
  saveCompressedBtn.addEventListener("click", async function () {
    try {
      const saveState = createSaveState(gThis);
      const stateJSON = JSON.stringify(saveState);

      await runCompress(gThis, stateJSON);

      console.log("Game state saved successfully");
    } catch (error) {
      console.error("Failed to save game state:", error);

      alert("Failed to save game state. Check console for details.");
    }
  });

  const loadExternalGameFileBtn = shadow.getElementById("loadExternalGameFile");
  loadExternalGameFileBtn.addEventListener("click", async function () {
    try {
      const currentSeedDisplay = shadow.getElementById("currentSeed");
      const seedInput = shadow.getElementById("worldSeedInput");

      let file;

      // Feature detection for showOpenFilePicker
      if (gThis.top === gThis && gThis.showOpenFilePicker) {
        const [fileHandle] = await gThis.showOpenFilePicker({
          types: [
            {
              description: "Sprite Garden Save Game Files",
              accept: {
                "application/*": [".sgs"],
                "application/pdf": [".pdf"],
                "text/plain": [".txt"],
              },
            },
          ],
        });

        file = await fileHandle.getFile();
      } else {
        // Fallback for browsers without showOpenFilePicker
        const input = gThis.document.createElement("input");
        input.type = "file";
        input.accept =
          ".sgs,.pdf,.txt,text/plain,application/pdf,application/gzip,application/*";
        input.style.display = "none";

        shadow.append(input);

        const filePromise = new Promise((resolve) => {
          input.onchange = () => resolve(input.files[0]);
        });

        input.click();

        file = await filePromise;
        shadow.removeChild(input);
      }

      let stateJSON = "{}";

      if (file.name.endsWith(".txt")) {
        stateJSON = (await file.text()).replace(/\s+/g, "");
      }

      if (file.name.endsWith(".pdf")) {
        const [results] = await extractAttachments(file);
        stateJSON = await extractJsonFromPng(new Blob([results.data]));
      }

      if (file.name.endsWith(".sgs")) {
        const decompressedStream = file
          .stream()
          .pipeThrough(new gThis.DecompressionStream("gzip"));

        const decompressedBlob = await new gThis.Response(
          decompressedStream,
        ).blob();

        stateJSON = await decompressedBlob.text();
      }

      // Validate the file is a valid game state before sharing
      let saveState;
      try {
        saveState = JSON.parse(stateJSON);
      } catch (parseError) {
        throw new Error("Invalid game state file: not valid JSON.");
      }

      // Verify required game state properties
      if (!saveState.config || !saveState.state) {
        throw new Error(
          "Invalid game state file: missing required config or state.",
        );
      }

      await loadSaveState(gThis, shadow, saveState);

      const { worldSeed } = saveState.config;

      if (seedInput instanceof HTMLInputElement) {
        seedInput.value = worldSeed;
      }

      currentSeedDisplay.textContent = worldSeed;

      console.log("Game state loaded successfully");
    } catch (error) {
      console.error("Failed to load game state:", error);
      alert("Failed to load game state. Check console for details.");
    }
  });

  let canShareFiles = false;
  const shareExternalGameFileBtn = shadow.getElementById(
    "shareExternalGameFile",
  );

  if (
    typeof navigator !== "undefined" &&
    typeof navigator.canShare !== "undefined"
  ) {
    // Test if we can actually share files
    try {
      canShareFiles = navigator.canShare({ files: [new File([], "test")] });
    } catch (e) {
      console.info(`File sharing is not enabled. ${JSON.stringify(e)}`);
    }
  }

  if (canShareFiles) {
    shadow
      .querySelectorAll(".seed-controls--share")
      .forEach((s) => s.removeAttribute("hidden"));

    shareExternalGameFileBtn.addEventListener("click", async function () {
      try {
        let file;

        // Feature detection for showOpenFilePicker
        if (gThis.top === gThis && gThis.showOpenFilePicker) {
          const [fileHandle] = await gThis.showOpenFilePicker({
            types: [
              {
                description: "Sprite Garden Save Game Files",
                accept: {
                  "application/*": [".sgs"],
                  "application/pdf": [".pdf"],
                  "text/plain": [".txt"],
                },
              },
            ],
          });

          file = await fileHandle.getFile();
        } else {
          // Fallback for browsers without showOpenFilePicker
          const input = gThis.document.createElement("input");
          input.type = "file";
          input.accept =
            ".sgs,.pdf,.txt,text/plain,application/pdf,application/gzip,application/*";
          input.style.display = "none";

          shadow.append(input);

          const filePromise = new Promise((resolve) => {
            input.onchange = () => resolve(input.files[0]);
          });

          input.click();

          file = await filePromise;
          shadow.removeChild(input);
        }

        let stateJSON = "{}";

        if (file.name.endsWith(".txt")) {
          stateJSON = (await file.text()).replace(/\s+/g, "");
        }

        if (file.name.endsWith(".pdf")) {
          const [results] = await extractAttachments(file);
          stateJSON = await extractJsonFromPng(new Blob([results.data]));
        }

        if (file.name.endsWith(".sgs")) {
          const decompressedStream = file
            .stream()
            .pipeThrough(new gThis.DecompressionStream("gzip"));

          const decompressedBlob = await new gThis.Response(
            decompressedStream,
          ).blob();

          stateJSON = await decompressedBlob.text();
        }

        // Validate the file is a valid game state before sharing
        let saveState;
        try {
          saveState = JSON.parse(stateJSON);
        } catch (parseError) {
          throw new Error("Invalid game state file: not valid JSON.");
        }

        // Verify required game state properties
        if (!saveState.config || !saveState.state) {
          throw new Error(
            "Invalid game state file: missing required config or state.",
          );
        }

        file = new File([stateJSON], `${file.name}.json.txt`, {
          type: "text/plain",
          lastModified: Date.now(),
        });

        // Check if we can share files
        if (
          typeof navigator !== "undefined" &&
          typeof navigator.canShare !== "undefined" &&
          navigator.canShare({ files: [file] })
        ) {
          await navigator.share({
            files: [file],
            title: "Sprite Garden Game Save",
            text: `Visit Sprite Garden, then 'Load' and checkout my world: ${file.name}\n\n`,
            url: "https://kherrick.github.io/sprite-garden",
          });

          console.log("Game state file shared successfully");
        } else {
          alert("Web Share API is not available on this device or browser.");
        }
      } catch (error) {
        // Only log if it's not a user cancellation
        if (error.name !== "AbortError") {
          console.error("Failed to share game state file:", error);
          alert("Failed to share game state file. Check console for details.");
        } else {
          console.log("Game state file sharing was cancelled by the user");
        }
      }
    });
  }

  // Add event listener for storage dialog button
  const openStorageBtn = shadow.getElementById("openStorageBtn");
  if (openStorageBtn) {
    openStorageBtn.addEventListener("click", async function () {
      try {
        await showStorageDialog(gThis, gThis.document, shadow);
      } catch (error) {
        console.error("Failed to open storage dialog:", error);

        alert("Failed to open storage dialog. Check console for details.");
      }
    });
  }

  const corners = shadow.querySelectorAll(".ui-grid__corner");
  corners.forEach((corner) => {
    const heading = corner.querySelector(".ui-grid__corner--heading");

    heading.addEventListener(
      "click",
      (
        /** @type MouseEvent */
        e,
      ) => handleCornerClick(e),
    );
  });
}

/**
 * @param {typeof globalThis} gThis
 * @param {ShadowRoot} shadow
 *
 * @returns {void}
 */
export function initElementEventListeners(gThis, shadow) {
  const resolutionSelectEl = shadow.getElementById("resolutionSelect");
  if (resolutionSelectEl) {
    resolutionSelectEl.addEventListener(
      "change",
      (
        /** @type {CustomEvent} */
        e,
      ) => {
        gameConfig.currentResolution.set(e.detail.value);

        resizeCanvas(shadow, gameConfig);
      },
    );
  }

  const toggleBtn = shadow.getElementById("toggleView");
  if (toggleBtn) {
    toggleBtn.addEventListener("click", () =>
      gameState.viewMode.set(
        gameState.viewMode.get() === "normal" ? "xray" : "normal",
      ),
    );
  }

  const toggleBreakBtn = shadow.getElementById("toggleBreakMode");
  if (toggleBreakBtn) {
    toggleBreakBtn.addEventListener("click", () => toggleBreakMode());
  }

  // Set up seed button event listeners
  const seedBtns = shadow.querySelectorAll(".seed-btn");
  seedBtns.forEach((btn) => {
    btn.addEventListener("click", (e) => selectSeed(shadow, gameState, e));
  });

  // Set up material button event listeners
  const materialBtns = shadow.querySelectorAll(".material-btn");
  materialBtns.forEach((btn) => {
    btn.addEventListener("click", (e) => selectMaterial(shadow, gameState, e));
  });

  // Set default to 400x400 and update the select element
  const sel = shadow.getElementById("resolutionSelect");
  if (sel instanceof HTMLSelectElement) {
    sel.value = "400";
  }
}
