const path = require("node:path");
const esbuild = require("./arcade-build/node_modules/esbuild");

const dependencies = path.join(__dirname, "arcade-build", "node_modules");
esbuild.build({
  absWorkingDir: __dirname,
  entryPoints: { game: "index.mjs" },
  outdir: "dist/assets",
  bundle: true,
  splitting: true,
  minify: true,
  format: "esm",
  target: "es2022",
  nodePaths: [dependencies],
  alias: { localforage: "./arcade-storage.mjs" },
  outExtension: { ".js": ".mjs" },
  plugins: [{
    name: "local-pdf-library",
    setup(build) {
      build.onResolve({ filter: /^https:\/\/cdn\.jsdelivr\.net\/npm\/pdf-lib\/\+esm$/ }, args =>
        build.resolve("pdf-lib", { resolveDir: dependencies, kind: args.kind }));
    },
  }],
}).catch(() => { process.exitCode = 1; });
