import { stringifyToLowerCase } from "../state/config/tiles.mjs";

/**
 * UI event handler for material selection.
 *
 * Toggles material selection in the inventory UI and updates game state.
 * Deselects the material if it's already selected (toggle behavior).
 *
 * @param {ShadowRoot} shadow - The shadow root of Sprite Garden
 * @param {Object} state - Game state object with selectedMaterialType Signal
 * @param {Event} event - Click event from the material button element
 *
 * @returns {void}
 */
export function selectMaterial(shadow, state, event) {
  if (!(event.currentTarget instanceof HTMLElement)) {
    throw new Error("currentTarget is not an HTMLElement");
  }

  const [materialType] = Object.keys(event.currentTarget.dataset);

  for (const el of event.currentTarget.parentElement.children) {
    el.classList.remove("selected");
  }

  event.currentTarget.classList.toggle("selected");

  console.log(`Selecting material: ${materialType}`);

  const currentSelected = state.selectedMaterialType.get();

  console.log(`Current selected material: ${currentSelected}`);

  const newSelected =
    currentSelected === materialType.toUpperCase()
      ? null
      : materialType.toUpperCase();

  state.selectedMaterialType.set(newSelected);

  let message;
  if (newSelected) {
    message = `New selected material: ${stringifyToLowerCase(newSelected)}`;
  } else {
    message = "No selected material.";
  }

  console.log(message);
  shadow.dispatchEvent(
    new CustomEvent("sprite-garden-toast", {
      detail: {
        message,
      },
    }),
  );
}
