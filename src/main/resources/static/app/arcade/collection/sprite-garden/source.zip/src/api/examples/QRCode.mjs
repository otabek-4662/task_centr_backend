import { SpriteGarden } from "../SpriteGarden.mjs";

export class QRCode extends SpriteGarden {
  url = "https://kherrick.github.io/sprite-garden/";
}

export async function demo(
  url = "https://kherrick.github.io/sprite-garden/",
  on = "SNOW",
  off = "COAL",
) {
  const api = new QRCode();

  api.url = url;

  // Setup
  await api.setFullscreen();
  api.setFogMode("clear");

  console.log("🎮 SpriteGarden Demo: QR Code");

  // Draw QR code
  const qrCodeResults = await api.drawQRCode(
    api.url,
    api.config.WORLD_WIDTH.get() / 2,
    api.config.SURFACE_LEVEL.get() + 20,
    api.tiles[on.toUpperCase()],
    api.tiles[off.toUpperCase()],
  );

  const apiText = "spriteGarden.demo.qrCodeAPI";

  console.log("📱 QR Code drawn!");
  console.log(`💡 Scan it to check it out!`);
  console.log(`💡 Use ${apiText}.tiles for variety!`);
  console.log(`💡 Use ${apiText}.drawQRCode() to create more!`);
  console.log(
    `💡 Example:
    ${apiText}.drawQRCode(
      "Hello World!",
      180,
      80,
      ${apiText}.tiles["${on.toUpperCase()}"],
      ${apiText}.tiles["${off.toUpperCase()}"]
    )`,
  );

  // Expose to console for interaction
  api.gThis.spriteGarden.demo = {
    ...api.gThis.spriteGarden.demo,
    why: true,
    qrCodeAPI: {
      ...api,
      result: qrCodeResults,
    },
  };
}
