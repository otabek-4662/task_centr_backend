const saveKey = "sprite-garden.v1";
const maxLength = 512000;
const bridge = globalThis.arcadeStorage;
const entries = new Map(JSON.parse(bridge?.getItem(saveKey) ?? "[]"));

function update(next) {
  const record = JSON.stringify([...next]);
  if (record.length > maxLength) {
    throw new Error("Saqlash joyi to‘ldi. Eski saqlangan dunyolarni o‘chiring.");
  }
  bridge?.setItem(saveKey, record);
  return next;
}

let storage = entries;
export default {
  async getItem(key) {
    return storage.get(key) ?? null;
  },
  async setItem(key, value) {
    storage = update(new Map(storage).set(key, value));
    return value;
  },
  async removeItem(key) {
    const next = new Map(storage);
    next.delete(key);
    storage = update(next);
  },
  async keys() {
    return [...storage.keys()];
  },
};
